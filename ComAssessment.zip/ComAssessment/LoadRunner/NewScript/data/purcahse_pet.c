purcahse_pet()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(18);

	web_url("Catalog.action_2", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_7", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"E6007F63-55E7-41CD-A419-C7615E591B2A\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name"
		"\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\""
		":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+"
		"GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Catalog.action_3", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_8", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"64036AE0-CA64-4EF1-B246-E3264E3638B5\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\""
		"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\""
		"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/"
		"ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
		"Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Cart.action", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_9", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"7E32DFA4-3C63-4EC1-994F-5EC14216DEB7\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\""
		"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\""
		"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/"
		"ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko"
		") Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		EXTRARES, 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toEhAJs4fpsup0xMoSBQ2uIGX9?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"99.0.1150.55");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.19044");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_url("find-assets_3", 
		"URL=https://edge.microsoft.com/entityextractiontemplates/api/v1/assets/find-assets?name=extraction.proactiveProduct.en-us&version=5.*.*&channel=stable&key=d414dd4f9db345fa8003e32adc81b362", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Order.action", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_10", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"26B22078-0F51-42BB-9E19-13294CC467E4\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrderForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\""
		"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		EXTRARES, 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toElYJ2G2dRPW1LEcSBQ2MZ-ueEgUNXu2YGRIFDb64KBcSBQ3xUZdYEgUNscrQvRIFDTdkz5sSBQ28Em2HEgUNBUx00hIFDQp-H7gSBQ1yfQF8EgUNREgf3w==?alt=proto", "Referer=", ENDITEM, 
		"Url=https://edgeassetservice.azureedge.net/assets/extraction.proactiveProduct.en-us/5.5.0/model_asset.edpm?sv=2017-07-29&sr=c&sig=U9QrcSkSepSZQLb4aa1mecNgQeRD6cH825NySstsd7k%3D&st=2021-01-01T00%3A00%3A00Z&se=2022-05-30T00%3A00%3A00Z&sp=r", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("2_11", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"B0E450B2-830F-40CB-BD6A-343D42FC4CC0\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,"
		"\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrderForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_custom_request("2_12", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"6C89028E-8925-47C0-AF65-8A1BBF85A1D2\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,"
		"\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrderForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("Order.action_2", 
		"Action=https://petstore.octoperf.com/actions/Order.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=order.cardType", "Value=Visa", ENDITEM, 
		"Name=order.creditCard", "Value=999 9999 9999 9999", ENDITEM, 
		"Name=order.expiryDate", "Value=12/03", ENDITEM, 
		"Name=order.billToFirstName", "Value=A", ENDITEM, 
		"Name=order.billToLastName", "Value=M", ENDITEM, 
		"Name=order.billAddress1", "Value=1, Vikas", ENDITEM, 
		"Name=order.billAddress2", "Value=", ENDITEM, 
		"Name=order.billCity", "Value=India", ENDITEM, 
		"Name=order.billState", "Value=India", ENDITEM, 
		"Name=order.billZip", "Value=400001", ENDITEM, 
		"Name=order.billCountry", "Value=India", ENDITEM, 
		"Name=newOrder", "Value=Continue", ENDITEM, 
		"Name=_sourcePage", "Value=Za7JOs4KyfrEkmnnwOq4dGrhmOtc9n6cQU9iiAFLItgzw20wqfbqP5aKue_TVvQy1kJn98chz_MbE5zSNxn8vHT1zk__lXt8l4lmbJ3uv5Q=", ENDITEM, 
		"Name=__fp", "Value=yvC7VPzhcfPeG_tEK7uCwQTifnELElNT-uRIaVSntjDzqAwjQrcdGdIbbfAhItxruaEFUp-jogjBXZwAurM4wlyN76FLSu2ZTNvZG50939dSepetqkhbHw==", ENDITEM, 
		LAST);

	web_link("Confirm", 
		"Text=Confirm", 
		"Snapshot=t37.inf", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_custom_request("2_13", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"27E1D007-7623-41F3-9F6A-F91C62185EC1\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\""
		"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\""
		":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+"
		"GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	return 0;
}
