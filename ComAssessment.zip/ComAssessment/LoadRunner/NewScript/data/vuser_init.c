/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_custom_request("2", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"FBC350BC-C91A-41DE-9F5E-E3C3A5C741A3\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,\"version\":\""
		"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637838863672079923\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\"enterprise\":null,"
		"\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":null,\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_custom_request("actions", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/actions", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"unknown\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"unknown\"}}},\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\""
		"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637838863672079923\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/"
		"9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"systemSettings\":{\"battery\":null,\"network\":null}}", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("99.0.1150.55", 
		"URL=https://config.edge.skype.com/config/v1/Edge/99.0.1150.55?clientId=8454288085638227936&osname=win&client=edge&channel=stable&scpfull=0&scpguard=0&scpfre=0&scpver=&osarch=x86_64&osver=10.0.19044&wu=1&devicefamily=desktop&uma=0&mngd=0&installdate=1615386096&edu=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(4);

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("ANON=; DOMAIN=www.bing.com");

	web_add_cookie("MUID=186989B80348679D1DD2993102FA6683; DOMAIN=www.bing.com");

	web_add_cookie("_RwBf=; DOMAIN=www.bing.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("getsupporteddomains", 
		"URL=https://www.bing.com/api/shopping/v1/getsupporteddomains?appid=67220BD2169C2EA709984467C21494086DF8CA85", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"clientContext\":{\"appname\":\"Edge\",\"buildversion\":\"99.0.1150.55\",\"enabledfeatures\":[{\"name\":\"msShoppingExp1\",\"params\":[]},{\"name\":\"msShoppingExp3\",\"params\":[]},{\"name\":\"msShoppingExp17\",\"params\":[]},{\"name\":\"msShoppingExp19\",\"params\":[]},{\"name\":\"msShoppingExp21\",\"params\":[]},{\"name\":\"msShoppingExp22\",\"params\":[]},{\"name\":\"msShoppingExp34\",\"params\":[]},{\"name\":\"msWebAssistQuery\",\"params\":[]},{\"name\":\"msEdgeShoppingPriceHistory\","
		"\"params\":[]},{\"name\":\"msEdgeShoppingExpressCheckout\",\"params\":[]},{\"name\":\"msEdgeShoppingGuestDomainCoupons\",\"params\":[]},{\"name\":\"msEdgeShoppingRewards\",\"params\":[]},{\"name\":\"msEdgeShoppingExpressCheckoutFillDetails\",\"params\":[]},{\"name\":\"msEdgeShoppingRebatesSignUp\",\"params\":[]},{\"name\":\"msEdgeShoppingAutoShowControlForFeature\",\"params\":[]},{\"name\":\"msEdgeShoppingAutoShowMuteForFeature\",\"params\":[{\"key\":\"duration\",\"value\":\"1\"}]},{\"name\":\""
		"msEdgePwiloPriceHistory\",\"params\":[]},{\"name\":\"msEdgeShoppingOtherSeller\",\"params\":[]},{\"name\":\"msEdgeShoppingWalmartOtherSeller\",\"params\":[]},{\"name\":\"msEdgePwiloItemDeletion\",\"params\":[]},{\"name\":\"msEdgeShoppingServerNotifications\",\"params\":[]},{\"name\":\"msEdgeShoppingPersistentStorage\",\"params\":[]},{\"name\":\"msEdgeShoppingAutoShowMuteForFeature\",\"params\":[{\"key\":\"duration\",\"value\":\"1\"}]}],\"ismobile\":false,\"osname\":\"Windows NT\",\"osversion\":\""
		"10.0.19044\"}}", 
		EXTRARES, 
		"Url=https://smartscreen-prod.microsoft.com/windows/browser/edge/data/bloomfilter/x?pushCert=false&flight="
		"%7B%22ETag%22%3A%22%5C%22mWWKOyEhUcbdbbKvoDkw%2B2jurvAOqBbxRHn9K6VxLq4%3D%5C%22%22%2C%22Ids%22%3A%5B%22P-R-86682-4-37%2CP-R-73000-4-25%2CP-R-72999-7-23%2CP-R-70204-3-18%2CP-R-69385-1-5%2CP-R-68026-3-37%2CP-R-68490-1-3%2CP-R-68172-2-4%2CP-R-68175-1-6%2CP-R-68176-2-8%2CP-R-68179-1-3%2CP-R-68306-1-20%2CP-R-68307-1-3%2CP-D-68194-1-2%22%5D%2C%22Settings%22%3A%7B%22Names%22%3Anull%2C%22Ring%22%3A0%2C%22Models%22%3Anull%2C%22ServiceClientModelDetonate%22%3Afalse%2C%22WdsiFeedback%22%3Afalse%2C%22NPFeedba"
		"ckUriOverride%22%3Anull%2C%22NetworkFilterDetonate%22%3Afalse%2C%22ServicePhishDetonate%22%3Afalse%2C%22ServicePhishDetonateLegacy%22%3Afalse%2C%22ServiceAdhocDetonate%22%3Afalse%2C%22NpSettings2004%22%3Atrue%2C%22UpdateSigningCert%22%3Atrue%2C%22UpdateSigningCertForRS3RS4%22%3Atrue%2C%22NpSettings2004Value%22%3A0%2C%22IsCOCOBlockEnabled%22%3Afalse%2C%22NpIpBlockOverrideValue%22%3A0%2C%22TopTrafficV2Enabled%22%3Atrue%2C%22ListApiE5V2Enabled%22%3Afalse%2C%22IsNpPIOverrideBlockEnabled%22%3Atrue%2C%2"
		"2TopTrafficV2MobileFlightEnabled%22%3Afalse%2C%22BloomFilterDeltaFlag%22%3A1%2C%22SrcEOPEnabled%22%3Atrue%2C%22IsCurfId0LoggingEnabled%22%3Atrue%2C%22IsCurfId0BlockingEnabled%22%3Afalse%2C%22UpdateOnMissingEtagEnabled%22%3Atrue%2C%22EnableProxyLeniency%22%3Atrue%2C%22IsArsFmsIntegrationEnabled%22%3Atrue%2C%22EnableNsHumorMatch%22%3Atrue%2C%22ApplyNsHumorVerdict%22%3Afalse%2C%22EnableNpSkipNonWeb%22%3Afalse%2C%22MTDThrottleFactor%22%3A0.0%2C%22UnsilenceModelGuid%22%3Anull%7D%7D&os="
		"10.0.19044.1586.vb_release", "Referer=", ENDITEM, 
		LAST);

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"99.0.1150.55");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.19044");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_url("blocklist", 
		"URL=https://edge.microsoft.com/abusiveadblocking/api/v1/blocklist", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("EdgeFeatureFlags", 
		"{\"ExtensionUseNewStoreKeys\":true,\"UseHttpsForDownload\":true}");

	web_add_header("MS-CV", 
		"P4f9X/tWtmM7nyw+GZQXb2");

	web_add_header("Update-Interactivity", 
		"bg");

	web_url("crx", 
		"URL=https://edge.microsoft.com/extensionwebstorebase/v1/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=edgecrx&prodchannel=&prodversion=99.0.1150.55&lang=en-US&acceptformat=crx3&x=id%3Denkbbdhdmbpfohfkfmdmjkpmolkbelgl%26v%3D1.3.8%26installedby%3Dinternal%26uc%26ping%3Dr%253D1%2526e%253D1&x=id%3Dijopbbfjlehabpldjiaipgiiedhfhbad%26v%3D2.1.0%26installedby%3Dinternal%26uc%26ping%3Dr%253D1%2526e%253D0%2526dr%253D1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("getsupporteddomains_2", 
		"URL=https://www.bing.com/api/shopping/v1/getsupporteddomains?appid=67220BD2169C2EA709984467C21494086DF8CA85", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"clientContext\":{\"appname\":\"Edge\",\"buildversion\":\"99.0.1150.55\",\"enabledfeatures\":[{\"name\":\"msShoppingExp1\",\"params\":[]},{\"name\":\"msShoppingExp3\",\"params\":[]},{\"name\":\"msShoppingExp17\",\"params\":[]},{\"name\":\"msShoppingExp19\",\"params\":[]},{\"name\":\"msShoppingExp21\",\"params\":[]},{\"name\":\"msShoppingExp22\",\"params\":[]},{\"name\":\"msShoppingExp34\",\"params\":[]},{\"name\":\"msWebAssistQuery\",\"params\":[]},{\"name\":\"msEdgeShoppingPriceHistory\","
		"\"params\":[]},{\"name\":\"msEdgeShoppingExpressCheckout\",\"params\":[]},{\"name\":\"msEdgeShoppingGuestDomainCoupons\",\"params\":[]},{\"name\":\"msEdgeShoppingRewards\",\"params\":[]},{\"name\":\"msEdgeShoppingExpressCheckoutFillDetails\",\"params\":[]},{\"name\":\"msEdgeShoppingRebatesSignUp\",\"params\":[]},{\"name\":\"msEdgeShoppingAutoShowControlForFeature\",\"params\":[]},{\"name\":\"msEdgeShoppingAutoShowMuteForFeature\",\"params\":[{\"key\":\"duration\",\"value\":\"1\"}]},{\"name\":\""
		"msEdgePwiloPriceHistory\",\"params\":[]},{\"name\":\"msEdgeShoppingOtherSeller\",\"params\":[]},{\"name\":\"msEdgeShoppingWalmartOtherSeller\",\"params\":[]},{\"name\":\"msEdgePwiloItemDeletion\",\"params\":[]},{\"name\":\"msEdgeShoppingServerNotifications\",\"params\":[]},{\"name\":\"msEdgeShoppingPersistentStorage\",\"params\":[]},{\"name\":\"msEdgeShoppingAutoShowMuteForFeature\",\"params\":[{\"key\":\"duration\",\"value\":\"1\"}]}],\"ismobile\":false,\"osname\":\"Windows NT\",\"osversion\":\""
		"10.0.19044\"}}", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_url("x", 
		"URL=https://smartscreen-prod.microsoft.com/windows/browser/edge/data/bloomfilter/x?pushCert=false&flight="
		"%7B%22ETag%22%3A%22%5C%22mWWKOyEhUcbdbbKvoDkw%2B2jurvAOqBbxRHn9K6VxLq4%3D%5C%22%22%2C%22Ids%22%3A%5B%22P-R-86682-4-37%2CP-R-73000-4-25%2CP-R-72999-7-23%2CP-R-70204-3-18%2CP-R-69385-1-5%2CP-R-68026-3-37%2CP-R-68490-1-3%2CP-R-68172-2-4%2CP-R-68175-1-6%2CP-R-68176-2-8%2CP-R-68179-1-3%2CP-R-68306-1-20%2CP-R-68307-1-3%2CP-D-68194-1-2%22%5D%2C%22Settings%22%3A%7B%22Names%22%3Anull%2C%22Ring%22%3A0%2C%22Models%22%3Anull%2C%22ServiceClientModelDetonate%22%3Afalse%2C%22WdsiFeedback%22%3Afalse%2C%22NPFeedba"
		"ckUriOverride%22%3Anull%2C%22NetworkFilterDetonate%22%3Afalse%2C%22ServicePhishDetonate%22%3Afalse%2C%22ServicePhishDetonateLegacy%22%3Afalse%2C%22ServiceAdhocDetonate%22%3Afalse%2C%22NpSettings2004%22%3Atrue%2C%22UpdateSigningCert%22%3Atrue%2C%22UpdateSigningCertForRS3RS4%22%3Atrue%2C%22NpSettings2004Value%22%3A0%2C%22IsCOCOBlockEnabled%22%3Afalse%2C%22NpIpBlockOverrideValue%22%3A0%2C%22TopTrafficV2Enabled%22%3Atrue%2C%22ListApiE5V2Enabled%22%3Afalse%2C%22IsNpPIOverrideBlockEnabled%22%3Atrue%2C%2"
		"2TopTrafficV2MobileFlightEnabled%22%3Afalse%2C%22BloomFilterDeltaFlag%22%3A1%2C%22SrcEOPEnabled%22%3Atrue%2C%22IsCurfId0LoggingEnabled%22%3Atrue%2C%22IsCurfId0BlockingEnabled%22%3Afalse%2C%22UpdateOnMissingEtagEnabled%22%3Atrue%2C%22EnableProxyLeniency%22%3Atrue%2C%22IsArsFmsIntegrationEnabled%22%3Atrue%2C%22EnableNsHumorMatch%22%3Atrue%2C%22ApplyNsHumorVerdict%22%3Afalse%2C%22EnableNpSkipNonWeb%22%3Afalse%2C%22MTDThrottleFactor%22%3A0.0%2C%22UnsilenceModelGuid%22%3Anull%7D%7D&os="
		"10.0.19044.1586.vb_release", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(4);

	web_url("Catalog.action", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_2", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"EC8B75D2-A950-4CAB-A5BA-1063842710F0\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null"
		",\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		EXTRARES, 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_to?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_auto_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_auto_header("Sec-Mesh-Client-Edge-Version", 
		"99.0.1150.55");

	web_add_auto_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_auto_header("Sec-Mesh-Client-OS-Version", 
		"10.0.19044");

	web_add_auto_header("Sec-Mesh-Client-WebView", 
		"0");

	web_url("find-assets", 
		"URL=https://edge.microsoft.com/entityextractiontemplates/api/v1/assets/find-assets?name=extraction.autofillFull.en-us&version=1.*.*&channel=stable&key=d414dd4f9db345fa8003e32adc81b362", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("find-assets_2", 
		"URL=https://edge.microsoft.com/entityextractiontemplates/api/v1/assets/find-assets?name=domains_config&version=1.*.*&channel=stable&key=d414dd4f9db345fa8003e32adc81b362", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
