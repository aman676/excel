login()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(14);

	web_url("Account.action_3", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signonForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_6", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"FF3E045E-7F89-4769-9E76-7E45A136D2CC\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?signonForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\""
		"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("Account.action_4", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?signonForm=", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={username}", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		"Name=_sourcePage", "Value=a-7Ln0b3hWsd7QvUQbvL46iKR40GFvw0ky4UE7HwHmgJtqHyZ7mdNJK__OEIMe4W5SxdIBvMO4nbR-HgdG6DUMiSny_G4qizYmvU9-wrb_U=", ENDITEM, 
		"Name=__fp", "Value=83znt5EsFkpRYksmCnlChH2oUYvTmicyUPNVedJ5XPgv9LatSdBW4jfHjplQ5NpU", ENDITEM, 
		LAST);

	return 0;
}
