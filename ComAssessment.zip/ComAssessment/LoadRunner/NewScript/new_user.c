new_user()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(31);

	web_url("Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_3", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"DCBB2EFC-4B4D-4D8E-BBFE-3C8A9158B134\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\""
		"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\""
		"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/"
		"ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/"
		"537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"99.0.1150.55");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.19044");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Microsoft-Update-AppId", 
		"ohckeflnhegojcjlcpbfpciadgikcohk,eeobbhfgfagbclfofmgbdfoicabjdbkn,oankkpibpaokgecfckkdkgaoafllipag,ndikpojcjlepofdkaaldkinkjbeeebkl,mkcgfaeepibomfapiapjaceihcojnphg,jbfaflocpnkhbgcijpkiafdpbjkedane,kpfehajjjbbcifeehjgfgnabifknmdad,fppmbhmldokgmleojlplaaodlkibgikh,ojblfafjmiikbkepnnolpgbbhejhlcim,plbmmhnabegcabfbcejohgjpkamkddhn,lfmeghnikdkbonehgjihjebgioakijgn,llmidpclgepbgbgoecnhcmgfhmfplfao,ahmaebgpfccdhgidjaidaoojjcijckba");

	web_add_header("X-Microsoft-Update-Interactivity", 
		"bg");

	web_add_header("X-Microsoft-Update-Updater", 
		"msedge-99.0.1150.55");

	web_custom_request("update", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update?cup2key=5:BeyjU8-WpZC4c-EjHj0ilYTAl15StB3IQ8NnnhDfy_k&cup2hreq=1feae2fa65a1d0afaf104881967e1a7916213c69dfa5d5d1e186a52a4bb1b969", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ohckeflnhegojcjlcpbfpciadgikcohk\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.75\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.26123BEF7D73536450862D2C4D44963D720AA80B6FC2D8496F559CB9C1FDEB00\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.75\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.75,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\""
		":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"0.0.1.4\"},{\"appid\":\"eeobbhfgfagbclfofmgbdfoicabjdbkn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.59\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.A7B3768750FC60664059FECF0E986A2E90718F18DE8E706EEBD99BC08BBB4AE4\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.59\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.59,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,"
		"\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"1.0.0.7\"},{\"appid\":\"oankkpibpaokgecfckkdkgaoafllipag\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.32\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.DD94940B6330D77E7797A60DE1183CCA7B0F71AB247BEA8F9AE0FF30EAFC379F\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.32\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.32,\"AppVersion\":\"99.0.1150.55\",\""
		"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"6498.2022.3.1\"},{\"appid\":\"ndikpojcjlepofdkaaldkinkjbeeebkl\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.87\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5C99949AA02BB6DC612C508CD6CCEDED5A0608ED1393F5C988A0F13F7EBE99F9\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.87\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.87,\"AppVersion\":\""
		"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"10.34.0.8\"},{\"appid\":\"mkcgfaeepibomfapiapjaceihcojnphg\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.48\",\"enabled\":true,\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.48\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.48,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\""
		"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"jbfaflocpnkhbgcijpkiafdpbjkedane\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.66\",\"enabled\":true,\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.66\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.66,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"1.0.0.21\"},{\"appid\":\""
		"kpfehajjjbbcifeehjgfgnabifknmdad\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.36\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.42AF0D1905C8F1D8F6167365271C4549A73603B838BA58B9A664C57C00DB1EE5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.36\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.36,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"101.0.4906.0"
		"\"},{\"appid\":\"fppmbhmldokgmleojlplaaodlkibgikh\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.89\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.A81D1959892AE4180554347DF1B97834ABBA2E1A5E6B9AEBA000ECEA26EABECC\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.89\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.89,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version"
		"\":\"1.15.0.1\"},{\"appid\":\"ojblfafjmiikbkepnnolpgbbhejhlcim\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.15\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.DE216CE8E4EA57D29906DCA850E914B4B09DD7B8AA89656317B94CD6FB0A6B7B\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.15\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.15,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":"
		"{},\"version\":\"4.10.2391.6\"},{\"appid\":\"plbmmhnabegcabfbcejohgjpkamkddhn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.45\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6B0D863FB0D9F196F54FE332B0621284E229EE61DD343A3C878D67D9D756CB46\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.45\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.45,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},"
		"\"updatecheck\":{},\"version\":\"2788\"},{\"appid\":\"lfmeghnikdkbonehgjihjebgioakijgn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.19\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6A223D620F1CD1EDB8E2A737220335C00D72510A947041B8EF5D33DB9726CC25\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.19\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.19,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\""
		"1.3.155.85\"},\"updatecheck\":{},\"version\":\"1.0.8.0\"},{\"appid\":\"llmidpclgepbgbgoecnhcmgfhmfplfao\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.57\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.8F791EBD171A2EF477D655044195126E775668EF5D09B966E1B553F276EF0ECC\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.57\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.57,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\""
		"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"2.0.0.1687\"},{\"appid\":\"ahmaebgpfccdhgidjaidaoojjcijckba\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.60\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.82497265352E024349DF20FCB72104978E8835933BF7497E11D8B1E0A8617AAE\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.60\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.6,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\""
		":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"3.0.0.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":1,\"physmemory\":8,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"sku\":\"desktop\",\"version\":\"10.0.19044.1586\"},\"prodversion\":\"99.0.1150.55\",\"protocol\":\"3.1\",\"requestid\":\""
		"{51a1a14a-88c3-491f-aec3-c0580f25cc44}\",\"sessionid\":\"{b74a3656-a73b-4196-beca-8ae933f57191}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":1,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.155.85\"},\"updaterversion\":\"99.0.1150.55\"}}", 
		EXTRARES, 
		"Url=/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toEhcJPBi8VCVDHfASBQ3njUAOEgUNzkFMeg==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_url("selection", 
		"URL=https://arc.msn.com/v4/api/selection?placement=88000360&nct=1&fmt=json&ADEFAB=1&OPSYS=WIN10&locale=en&country=IN&edgeid=8454288085638227936&ACHANNEL=4&ABUILD=99.0.4844.74&poptin=0&devosver=10.0.19044.1586&clr=esdk&UITHEME=dark&EPCON=0&AMAJOR=99&AMINOR=0&ABLD=4844&APATCH=74", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Account.action", 
		"URL=https://petstore.octoperf.com/actions/Account.action?newAccountForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2_4", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"F0F5FE25-BCB1-4966-A4A6-6B56765D5B69\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?newAccountForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\","
		"\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/"
		"99.0.1150.55\"}", 
		EXTRARES, 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toEnIJqXZ-_ZpY3OcSBQ3njUAOEgUNfIBTNRIFDRUITQYSBQ2crfNgEgUNaKQD3xIFDZBGwn0SBQ3E4iHbEgUNx1UqgxIFDc_G5MUSBQ0xG2D5EgUNxJ9-mhIFDZnXOncSBQ35td1wEgUNuzX3xRIFDfvVE3o=?alt=proto", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(37);

	web_custom_request("2_5", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"76505FA8-1EEB-49AC-B5CB-13143CEDB9A9\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null"
		",\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?newAccountForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		LAST);

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("Account.action_2", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?newAccountForm=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={username}", ENDITEM, 
		"Name=repeatedPassword", "Value={username}", ENDITEM, 
		"Name=account.firstName", "Value=A", ENDITEM, 
		"Name=account.lastName", "Value=M", ENDITEM, 
		"Name=account.email", "Value=am@gmail.com", ENDITEM, 
		"Name=account.phone", "Value=9999900000", ENDITEM, 
		"Name=account.address1", "Value=1, Vikas", ENDITEM, 
		"Name=account.address2", "Value=", ENDITEM, 
		"Name=account.city", "Value=India", ENDITEM, 
		"Name=account.state", "Value=India", ENDITEM, 
		"Name=account.zip", "Value=400001", ENDITEM, 
		"Name=account.country", "Value=India", ENDITEM, 
		"Name=account.languagePreference", "Value=english", ENDITEM, 
		"Name=account.favouriteCategoryId", "Value=FISH", ENDITEM, 
		"Name=newAccount", "Value=Save Account Information", ENDITEM, 
		"Name=_sourcePage", "Value=op3TLjXBzVnIXy_YieWIigiPRCIE3bUvqe_yyP1_p4YBV6z3byivrNw6anBTSxx9MYnfDWMrvfpVp0WKCNdY1ruZ2nPrdWb-PgpFbrNhnH4=", ENDITEM, 
		"Name=__fp", "Value=xM1qIrjoh6HZWiEWKmdNyt5Fya_KvPzrdQC85mSNuQQDfrl1XGK6OgcFhX8c1s3nHmjay1AGn_UuajkJ9GhYf3uOzlTtKdzJipudBbsWtzCDoG8kdQB9LOF9-2lRmCsmnGjvTW0npyh9nf1ojTmKKVvhufZVEQv7oxQBD9akpnTE-hZkF5XdXevTddIrXyJe", ENDITEM, 
		LAST);

	return 0;
}
