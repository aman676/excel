# 1 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c"
# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_search_row(PVCI pvci, char * columnNames, char * messages, char * delimiter, char * **outcolumns, char * **outvalues);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_search_row(char * columnNames, char * messages, char * delimiter);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_search_row(PVCI2 pvci, char *columnNames, char *messages, char *delimiter, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_search_row(char *columnNames, char *messages, char *delimiter);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "lrw_custom_body.h" 1
 




# 8 "globals.h" 2


 
 


# 3 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "vuser_init.c" 1
 







vuser_init()
{

	

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

	

	web_url("Catalog.action", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"LAST");

	
	return 0;
}
# 4 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "Action.c" 1
Action()
{
	return 0;
}
# 5 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "new_user.c" 1
new_user()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(31);

	web_url("Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_3", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"DCBB2EFC-4B4D-4D8E-BBFE-3C8A9158B134\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\""
		"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\""
		"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/"
		"ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/"
		"537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"99.0.1150.55");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.19044");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Microsoft-Update-AppId", 
		"ohckeflnhegojcjlcpbfpciadgikcohk,eeobbhfgfagbclfofmgbdfoicabjdbkn,oankkpibpaokgecfckkdkgaoafllipag,ndikpojcjlepofdkaaldkinkjbeeebkl,mkcgfaeepibomfapiapjaceihcojnphg,jbfaflocpnkhbgcijpkiafdpbjkedane,kpfehajjjbbcifeehjgfgnabifknmdad,fppmbhmldokgmleojlplaaodlkibgikh,ojblfafjmiikbkepnnolpgbbhejhlcim,plbmmhnabegcabfbcejohgjpkamkddhn,lfmeghnikdkbonehgjihjebgioakijgn,llmidpclgepbgbgoecnhcmgfhmfplfao,ahmaebgpfccdhgidjaidaoojjcijckba");

	web_add_header("X-Microsoft-Update-Interactivity", 
		"bg");

	web_add_header("X-Microsoft-Update-Updater", 
		"msedge-99.0.1150.55");

	web_custom_request("update", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update?cup2key=5:BeyjU8-WpZC4c-EjHj0ilYTAl15StB3IQ8NnnhDfy_k&cup2hreq=1feae2fa65a1d0afaf104881967e1a7916213c69dfa5d5d1e186a52a4bb1b969", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ohckeflnhegojcjlcpbfpciadgikcohk\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.75\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.26123BEF7D73536450862D2C4D44963D720AA80B6FC2D8496F559CB9C1FDEB00\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.75\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.75,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\""
		":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"0.0.1.4\"},{\"appid\":\"eeobbhfgfagbclfofmgbdfoicabjdbkn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.59\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.A7B3768750FC60664059FECF0E986A2E90718F18DE8E706EEBD99BC08BBB4AE4\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.59\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.59,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,"
		"\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"1.0.0.7\"},{\"appid\":\"oankkpibpaokgecfckkdkgaoafllipag\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.32\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.DD94940B6330D77E7797A60DE1183CCA7B0F71AB247BEA8F9AE0FF30EAFC379F\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.32\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.32,\"AppVersion\":\"99.0.1150.55\",\""
		"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"6498.2022.3.1\"},{\"appid\":\"ndikpojcjlepofdkaaldkinkjbeeebkl\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.87\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5C99949AA02BB6DC612C508CD6CCEDED5A0608ED1393F5C988A0F13F7EBE99F9\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.87\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.87,\"AppVersion\":\""
		"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"10.34.0.8\"},{\"appid\":\"mkcgfaeepibomfapiapjaceihcojnphg\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.48\",\"enabled\":true,\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.48\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.48,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\""
		"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"jbfaflocpnkhbgcijpkiafdpbjkedane\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.66\",\"enabled\":true,\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.66\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.66,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"1.0.0.21\"},{\"appid\":\""
		"kpfehajjjbbcifeehjgfgnabifknmdad\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.36\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.42AF0D1905C8F1D8F6167365271C4549A73603B838BA58B9A664C57C00DB1EE5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.36\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.36,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"101.0.4906.0"
		"\"},{\"appid\":\"fppmbhmldokgmleojlplaaodlkibgikh\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.89\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.A81D1959892AE4180554347DF1B97834ABBA2E1A5E6B9AEBA000ECEA26EABECC\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.89\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.89,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version"
		"\":\"1.15.0.1\"},{\"appid\":\"ojblfafjmiikbkepnnolpgbbhejhlcim\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.15\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.DE216CE8E4EA57D29906DCA850E914B4B09DD7B8AA89656317B94CD6FB0A6B7B\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.15\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.15,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":"
		"{},\"version\":\"4.10.2391.6\"},{\"appid\":\"plbmmhnabegcabfbcejohgjpkamkddhn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.45\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6B0D863FB0D9F196F54FE332B0621284E229EE61DD343A3C878D67D9D756CB46\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.45\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.45,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},"
		"\"updatecheck\":{},\"version\":\"2788\"},{\"appid\":\"lfmeghnikdkbonehgjihjebgioakijgn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.19\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6A223D620F1CD1EDB8E2A737220335C00D72510A947041B8EF5D33DB9726CC25\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.19\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.19,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\""
		"1.3.155.85\"},\"updatecheck\":{},\"version\":\"1.0.8.0\"},{\"appid\":\"llmidpclgepbgbgoecnhcmgfhmfplfao\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.57\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.8F791EBD171A2EF477D655044195126E775668EF5D09B966E1B553F276EF0ECC\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.57\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.57,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\""
		"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"2.0.0.1687\"},{\"appid\":\"ahmaebgpfccdhgidjaidaoojjcijckba\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.60\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.82497265352E024349DF20FCB72104978E8835933BF7497E11D8B1E0A8617AAE\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.60\",\"AppMajorVersion\":\"99\",\"AppRollout\":0.6,\"AppVersion\":\"99.0.1150.55\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\""
		":\"Omaha\",\"UpdaterVersion\":\"1.3.155.85\"},\"updatecheck\":{},\"version\":\"3.0.0.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":1,\"physmemory\":8,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"sku\":\"desktop\",\"version\":\"10.0.19044.1586\"},\"prodversion\":\"99.0.1150.55\",\"protocol\":\"3.1\",\"requestid\":\""
		"{51a1a14a-88c3-491f-aec3-c0580f25cc44}\",\"sessionid\":\"{b74a3656-a73b-4196-beca-8ae933f57191}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":1,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.155.85\"},\"updaterversion\":\"99.0.1150.55\"}}", 
		"EXTRARES", 
		"Url=/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toEhcJPBi8VCVDHfASBQ3njUAOEgUNzkFMeg==?alt=proto", "Referer=", "ENDITEM", 
		"LAST");

	web_url("selection", 
		"URL=https://arc.msn.com/v4/api/selection?placement=88000360&nct=1&fmt=json&ADEFAB=1&OPSYS=WIN10&locale=en&country=IN&edgeid=8454288085638227936&ACHANNEL=4&ABUILD=99.0.4844.74&poptin=0&devosver=10.0.19044.1586&clr=esdk&UITHEME=dark&EPCON=0&AMAJOR=99&AMINOR=0&ABLD=4844&APATCH=74", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("Sec-Fetch-Dest", "ImplicitGen=Yes", "LAST"));

	web_add_header("Sec-Fetch-Dest", 
		"document");

	(web_remove_auto_header("Sec-Fetch-Mode", "ImplicitGen=Yes", "LAST"));

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	(web_remove_auto_header("Sec-Fetch-Site", "ImplicitGen=Yes", "LAST"));

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Account.action", 
		"URL=https://petstore.octoperf.com/actions/Account.action?newAccountForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_4", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"F0F5FE25-BCB1-4966-A4A6-6B56765D5B69\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?newAccountForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\","
		"\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action;jsessionid=AD8DC83251F23F592175E96BB227206A?signonForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/"
		"99.0.1150.55\"}", 
		"EXTRARES", 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toEnIJqXZ-_ZpY3OcSBQ3njUAOEgUNfIBTNRIFDRUITQYSBQ2crfNgEgUNaKQD3xIFDZBGwn0SBQ3E4iHbEgUNx1UqgxIFDc_G5MUSBQ0xG2D5EgUNxJ9-mhIFDZnXOncSBQ35td1wEgUNuzX3xRIFDfvVE3o=?alt=proto", "Referer=", "ENDITEM", 
		"LAST");

	lr_think_time(37);

	web_custom_request("2_5", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"76505FA8-1EEB-49AC-B5CB-13143CEDB9A9\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null"
		",\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?newAccountForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("Account.action_2", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?newAccountForm=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		"ITEMDATA", 
		"Name=username", "Value={username}", "ENDITEM", 
		"Name=password", "Value={username}", "ENDITEM", 
		"Name=repeatedPassword", "Value={username}", "ENDITEM", 
		"Name=account.firstName", "Value=A", "ENDITEM", 
		"Name=account.lastName", "Value=M", "ENDITEM", 
		"Name=account.email", "Value=am@gmail.com", "ENDITEM", 
		"Name=account.phone", "Value=9999900000", "ENDITEM", 
		"Name=account.address1", "Value=1, Vikas", "ENDITEM", 
		"Name=account.address2", "Value=", "ENDITEM", 
		"Name=account.city", "Value=India", "ENDITEM", 
		"Name=account.state", "Value=India", "ENDITEM", 
		"Name=account.zip", "Value=400001", "ENDITEM", 
		"Name=account.country", "Value=India", "ENDITEM", 
		"Name=account.languagePreference", "Value=english", "ENDITEM", 
		"Name=account.favouriteCategoryId", "Value=FISH", "ENDITEM", 
		"Name=newAccount", "Value=Save Account Information", "ENDITEM", 
		"Name=_sourcePage", "Value=op3TLjXBzVnIXy_YieWIigiPRCIE3bUvqe_yyP1_p4YBV6z3byivrNw6anBTSxx9MYnfDWMrvfpVp0WKCNdY1ruZ2nPrdWb-PgpFbrNhnH4=", "ENDITEM", 
		"Name=__fp", "Value=xM1qIrjoh6HZWiEWKmdNyt5Fya_KvPzrdQC85mSNuQQDfrl1XGK6OgcFhX8c1s3nHmjay1AGn_UuajkJ9GhYf3uOzlTtKdzJipudBbsWtzCDoG8kdQB9LOF9-2lRmCsmnGjvTW0npyh9nf1ojTmKKVvhufZVEQv7oxQBD9akpnTE-hZkF5XdXevTddIrXyJe", "ENDITEM", 
		"LAST");

	return 0;
}
# 6 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "login.c" 1
login()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(14);

	web_url("Account.action_3", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signonForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_6", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"FF3E045E-7F89-4769-9E76-7E45A136D2CC\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?signonForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\""
		"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("Account.action_4", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action?signonForm=", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=username", "Value={username}", "ENDITEM", 
		"Name=password", "Value={username}", "ENDITEM", 
		"Name=signon", "Value=Login", "ENDITEM", 
		"Name=_sourcePage", "Value=a-7Ln0b3hWsd7QvUQbvL46iKR40GFvw0ky4UE7HwHmgJtqHyZ7mdNJK__OEIMe4W5SxdIBvMO4nbR-HgdG6DUMiSny_G4qizYmvU9-wrb_U=", "ENDITEM", 
		"Name=__fp", "Value=83znt5EsFkpRYksmCnlChH2oUYvTmicyUPNVedJ5XPgv9LatSdBW4jfHjplQ5NpU", "ENDITEM", 
		"LAST");

	return 0;
}
# 7 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "purcahse_pet.c" 1
purcahse_pet()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(18);

	web_url("Catalog.action_2", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_7", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"E6007F63-55E7-41CD-A419-C7615E591B2A\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name"
		"\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\""
		":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+"
		"GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Catalog.action_3", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_8", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"64036AE0-CA64-4EF1-B246-E3264E3638B5\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\""
		"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\""
		"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/"
		"ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=DOGS\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
		"Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Cart.action", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_9", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"7E32DFA4-3C63-4EC1-994F-5EC14216DEB7\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\""
		"name\":\"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\""
		"cloudSku\":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/"
		"ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=K9-BD-01\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko"
		") Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"EXTRARES", 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toEhAJs4fpsup0xMoSBQ2uIGX9?alt=proto", "Referer=", "ENDITEM", 
		"LAST");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"99.0.1150.55");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.19044");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_url("find-assets_3", 
		"URL=https://edge.microsoft.com/entityextractiontemplates/api/v1/assets/find-assets?name=extraction.proactiveProduct.en-us&version=5.*.*&channel=stable&key=d414dd4f9db345fa8003e32adc81b362", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Order.action", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("2_10", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"26B22078-0F51-42BB-9E19-13294CC467E4\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrderForm=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\""
		"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-6\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"EXTRARES", 
		"Url=https://edge.microsoft.com/autofillservice/v1/pages/ChNDaHJvbWUvOTkuMC40ODQ0Ljc0EhAJ34e8yo8bLA8SBQ0Cj_toElYJ2G2dRPW1LEcSBQ2MZ-ueEgUNXu2YGRIFDb64KBcSBQ3xUZdYEgUNscrQvRIFDTdkz5sSBQ28Em2HEgUNBUx00hIFDQp-H7gSBQ1yfQF8EgUNREgf3w==?alt=proto", "Referer=", "ENDITEM", 
		"Url=https://edgeassetservice.azureedge.net/assets/extraction.proactiveProduct.en-us/5.5.0/model_asset.edpm?sv=2017-07-29&sr=c&sig=U9QrcSkSepSZQLb4aa1mecNgQeRD6cH825NySstsd7k%3D&st=2021-01-01T00%3A00%3A00Z&se=2022-05-30T00%3A00%3A00Z&sp=r", "Referer=", "ENDITEM", 
		"LAST");

	web_custom_request("2_11", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"B0E450B2-830F-40CB-BD6A-343D42FC4CC0\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,"
		"\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrderForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_custom_request("2_12", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"6C89028E-8925-47C0-AF65-8A1BBF85A1D2\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\"process\":null,"
		"\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\"customId\":null,\""
		"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\",\"osVersion\":\""
		"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrderForm=\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("Order.action_2", 
		"Action=https://petstore.octoperf.com/actions/Order.action", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=order.cardType", "Value=Visa", "ENDITEM", 
		"Name=order.creditCard", "Value=999 9999 9999 9999", "ENDITEM", 
		"Name=order.expiryDate", "Value=12/03", "ENDITEM", 
		"Name=order.billToFirstName", "Value=A", "ENDITEM", 
		"Name=order.billToLastName", "Value=M", "ENDITEM", 
		"Name=order.billAddress1", "Value=1, Vikas", "ENDITEM", 
		"Name=order.billAddress2", "Value=", "ENDITEM", 
		"Name=order.billCity", "Value=India", "ENDITEM", 
		"Name=order.billState", "Value=India", "ENDITEM", 
		"Name=order.billZip", "Value=400001", "ENDITEM", 
		"Name=order.billCountry", "Value=India", "ENDITEM", 
		"Name=newOrder", "Value=Continue", "ENDITEM", 
		"Name=_sourcePage", "Value=Za7JOs4KyfrEkmnnwOq4dGrhmOtc9n6cQU9iiAFLItgzw20wqfbqP5aKue_TVvQy1kJn98chz_MbE5zSNxn8vHT1zk__lXt8l4lmbJ3uv5Q=", "ENDITEM", 
		"Name=__fp", "Value=yvC7VPzhcfPeG_tEK7uCwQTifnELElNT-uRIaVSntjDzqAwjQrcdGdIbbfAhItxruaEFUp-jogjBXZwAurM4wlyN76FLSu2ZTNvZG50939dSepetqkhbHw==", "ENDITEM", 
		"LAST");

	web_link("Confirm", 
		"Text=Confirm", 
		"Snapshot=t37.inf", 
		"LAST");

	(web_remove_auto_header("Sec-Fetch-Dest", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("Sec-Fetch-Mode", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("Sec-Fetch-Site", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("Sec-Fetch-User", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("Upgrade-Insecure-Requests", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-mobile", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-platform", "ImplicitGen=Yes", "LAST"));

	web_custom_request("2_13", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"27E1D007-7623-41F3-9F6A-F91C62185EC1\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\""
		"anaheim\",\"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\""
		":false,\"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+"
		"GgE=&p=\",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	return 0;
}
# 8 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{

	web_custom_request("2_14", 
		"URL=https://nav.smartscreen.microsoft.com/api/browser/edge/navigate/2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"config\":{\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"},\"pua\":null},\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"correlationId\":\"D13FC675-2D31-40F8-A899-3FE40DE9B653\",\"destination\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Account.action?signoff=\"},\"forceServiceDetermination\":false,\"identity\":{\"caller\":{\"locale\":\"en-GB\",\"name\":\"anaheim\",\""
		"process\":null,\"version\":\"99.0.1150.55 (Official build) \"},\"client\":{\"data\":{\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\",\"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-2f9188b68640dbf72295f9083a21d674a314721ef06f82db281cbcb052ff8ec1\",\"synchronousLookupUris\":\"637839762430317231\",\"topTraffic\":\"637811103879324684\"},\"version\":\"281479416053761\"},\"device\":{\"architecture\":9,\"browser\":{\"internetExplorer\":\"9.11.19041.0\"},\"cloudSku\":false,\""
		"customId\":null,\"enterprise\":null,\"family\":3,\"id\":null,\"locale\":\"en-GB\",\"netJoinStatus\":2,\"onlineIdTicket\":\"t=GwAWAd9tBAAUa9NnKxE2EcNyf3boVjyC/9kKG5YOZgAAEDGpZqdZOdoydJu6oR2eRg7gADLXTr4kQbYbbXolHqTCN5UTxwCvTDFOf86XPgEBMT2BgLqwvYKnNrZGfZ+pd+A+SdCvxIXtEi1prfpmBFoXbuE+1ZmienCxLQEvEiA/EvX/sYh4BNyqqdsCqRoIfXLxmFQ8WUY6luvgYzHBrS14XkV2Xs3jcVQ6NnVJgHCYgz7dIaQKqFJK1IZawGzsceNHDRYYBrWWP+AJqUgnW/AXbdifTNG3yvXls48HlN0sZ11tglR/ZYPGGVwd7jitY2NTZVmYhaztkwDi20kJAvxHUccbkpBjInIuKb5i2ehwm5J+GgE=&p=\""
		",\"osVersion\":\"10.0.19044.1586.vb_release\"},\"user\":{\"locale\":\"en-GB\"}},\"referrer\":{\"ip\":null,\"uri\":\"https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true\"},\"serverContext\":null,\"signals\":null,\"synchronous\":false,\"systemSettings\":{\"battery\":null,\"network\":null},\"type\":\"top\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.55\"}", 
		"LAST");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Account.action_5", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signoff=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"LAST");

	return 0;
}
# 9 "c:\\users\\lenovo\\desktop\\mindtree\\testscript\\loadrunner\\newscript\\\\combined_NewScript.c" 2

